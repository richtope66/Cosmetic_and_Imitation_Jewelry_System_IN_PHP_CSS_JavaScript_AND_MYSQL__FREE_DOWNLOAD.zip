<html>

	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
		<title>Ananya Cosmetics</title>
		
		<link href="css/bootstrap.min.css" rel="stylesheet" />
		<link href="css/style.css" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
        <link rel="stylesheet" type="text/css" href="css/tips.css" />

<!-- js files -->
<!-- color picker -->
<!-- jQuery framework -->
<script type="text/javascript" src="jscolor/jscolor.js"></script>
<!-- jQuery framework -->
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<!-- jQueriy easing plugin-->
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<!-- lhpTwoColorButton plugin -->
<script type="text/javascript" src="js/jquery.lhpTwoColorButton.min.js"></script>
<!-- lhpTwoColorButton plugin -->
<script type="text/javascript" src="js/jquery.lhpMenuTwoColorButton.min.js"></script>
<!-- preview main js code -->
<script type="text/javascript" src="js/main.js"></script>

<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<!-- jQueriy easing plugin-->
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<!-- lhpTwoColorButton plugin -->
<script type="text/javascript" src="js/jquery.lhpTwoColorButton.min.js"></script>
<!-- lhpTwoColorButton plugin -->
<!-- preview main js code -->
<script type="text/javascript" src="js/main.js"></script>

<script type="text/javascript" src="jscolor/jscolor.js"></script>
        
		<link href="css/nouislider.css" rel="stylesheet" />
		<!--[if lt IE 9]><link rel="stylesheet" type="text/css" href="css/ie8.css" /><![endif]-->
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" /></head>

	<body class="category">
		<div class="header-container">
			<div class="diagonal-holder visible-desktop">
				<div class="slider-diagonal-overflow">
					<div class="slider-diagonal rotate315"></div>
				</div>
			</div>
			<div class="container">
				<div class="row">
					<div class="span12">
						<div class="header">
							<div class="row" style="overflow: visible;">
								<div class="span3">
									<p class="login-p">&nbsp;</p>
								</div>
								
								<div class="span3 offset1">
									<div class="top-options">
										<div class="top-options-meta">
											&nbsp;
										</div>
										<div class="drop-down" id="language-drop-down">
											&nbsp;
										</div>
										<div class="drop-down" id="currency-drop-down">
										&nbsp;
										</div>
									</div>
								</div>
							</div>

							<div class="row">
								<div class="span3">
									<a href="#" id="logo"><img class="logo_c" src="media/LOGO/logo.png"></a>
								</div>
								<div class="span8 offset1">
									<ul id="menu">
                                    <li><a href="index.html">Home</a>
									  <li><a href="products.html">Products</a> 
											<div class="child-nav" style="display: none;">
												<div class="child-menu">
													<ul class="child-menu-main">
														<li><a href="category.html">OLAY</a></li>
														<li><a href="category.html">LAKME</a></li>
														<li><a href="category.html">DOVE</a></li>
														<li><a href="category.html">GARNIER</a></li>
														<li><a href="category.html">PONDS</a></li>
														<li><a href="category.html">L'OREAL</a></li>
														<li><a href="category.html">...</a></li>
														<li><a href="category.html">...</a></li>
													</ul>
													<ul class="child-menu-context">
														<li>+ <a href="category.html">new arrivals</a></li>
														<li>+ <a href="category.html">sale</a></li>
														<li>+ <a href="category.html">view all</a></li>
													</ul>
												</div>
												<div class="child-promo">
													<h2>Special Offer</h2>
													<div class="child-promo-box">
														<img class="child-promo" src="media/drop-down.png" alt="product" />
														<div class="child-promo-overlay">
															<a href="category.html">30% off knitwear</a>
															<p>Only this week. Go get it!</p>
														</div>
													</div>
												</div>
											</div>
										</li>
										<li><a href="imitation.html">Jwellery</a> /</li>
										<li><a href="main_category.html">Tips</a> /</li>
										<li><a href="contact.html">Contact</a></li>
										
										
								  </ul>
								</div>
							</div>
							</div>
						</div><!-- end header -->
					</div>
				</div>
			</div><!-- end container -->
		</div><!-- end header container -->


		<div class="container push-below-header">
			<div class="row">
				<div class="span3 side-options phone-span-diff">
					<h3 class="subheading">Categories</h3>
					<ul class="side-nav">
						<li>
							<a href="main_category.html">Women (155)</a>
							<ul class="side-nav-second hidden-phone">
								<li>/ <a href="category.html">New Arrivals (10)</a></li>
								<li>/ <a href="category.html">Dresses (20)</a></li>
								<li>/ <a href="category.html">Shorts (8)</a></li>
								<li>/ <a href="category.html">Skirts (17)</a></li>
								<li>/ <a href="category.html">Jeans (23)</a></li>
								<li>/ <a href="category.html">Tops (54)</a></li>
								<li>/ <a href="category.html">Suits & Tailoring (5)</a></li>
								<li>/ <a href="category.html">Jackets & Coats (16)</a></li>
							</ul>
						</li>
						<li><a href="main_category.html">Men (105)</a></li>
						<li><a href="main_category.html">Juniors (84)</a></li>
						<li><a href="main_category.html">Kids (49)</a></li>
						<li><a href="main_category.html">Shoes (574)</a></li>
						<li><a href="main_category.html">Sale (52)</a></li>
					</ul>
					<h3 class="subheading">Brands</h3>
					<ul class="side-nav">
						<li>
							<input type="checkbox" id="brand1" />
							<label for="brand1">Dress Brand</label>
						</li>
						<li>
							<input type="checkbox" id="brand2" />
							<label for="brand2">Another Brand</label>
						</li>
						<li>
							<input type="checkbox" id="brand3" />
							<label for="brand3">Diagonal</label>
						</li>
						<li>
							<input type="checkbox" id="brand4" />
							<label for="brand4">JGrozdanov</label>
						</li>
						<li>
							<input type="checkbox" id="brand5" />
							<label for="brand5">HTML Template</label>
						</li>
					</ul>
					<a href="#" class="more hidden-phone">more</a>
					<a href="#" class="down-arrow rotate90">></a>
					<h3 class="subheading">Styles</h3>
					<ul class="side-nav">
						<li>
							<input type="checkbox" id="style1" />
							<label for="style1">Cocktail</label>
						</li>
						<li>
							<input type="checkbox" id="style2" />
							<label for="style2">Bodycon</label>
						</li>
						<li>
							<input type="checkbox" id="style3" />
							<label for="style3">Mini</label>
						</li>
						<li>
							<input type="checkbox" id="style4" />
							<label for="style4">Jump Suit</label>
						</li>
						<li>
							<input type="checkbox" id="style5" />
							<label for="style5">Mid-length</label>
						</li>
					</ul>
					<a href="#" class="more hidden-phone">more</a>
					<a href="#" class="down-arrow rotate90">></a>
					<h3 class="subheading">Size</h3>
					<ul class="side-nav">
						<li>
							<input type="checkbox" id="size1" />
							<label for="size1">XS</label>
						</li>
						<li>
							<input type="checkbox" id="size2" />
							<label for="size2">S</label>
						</li>
						<li>
							<input type="checkbox" id="size3" />
							<label for="size3">M</label>
						</li>
						<li>
							<input type="checkbox" id="size4" />
							<label for="size4">L</label>
						</li>
						<li>
							<input type="checkbox" id="size5" />
							<label for="size5">XL</label>
						</li>
					</ul>
					<a href="#" class="more hidden-phone">more</a>
					<a href="#" class="down-arrow rotate90">></a>
					<h3 class="subheading">Colours</h3>
					<div class="row">
						<div class="span3 phone-center">
							<div class="colour blue"></div>
							<div class="colour cyan"></div>
							<div class="colour black"></div>
							<div class="colour navy"></div>
							<div class="colour yellow"></div>
							<div class="colour green"></div>
							<div class="colour frog"></div>
							<div class="colour violet"></div>
						</div>
					</div>
					<h3 class="subheading">Price</h3>
					<div class="row">
						<div class="span3">
							<div id="range-slider">
							</div>
						</div>
					</div>
					<div class="row">
						<div class="span3">
							<a href="#" class="clear push50">clear all</a>
						</div>
					</div>
				</div>

				<div class="span9">
					<div class="row">
						<div class="span9">
							<div class="breadcrumbs-big phone-center">
								<a href="index.html">home</a>
								<span> / </span>
								<a href="main_category.html">women</a>
								<span> / </span>
								<a href="#">dresses</a>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="span9">
							<div class="category-frame">
								<div class="frame-overflow-keeper">
									<img class="category-image" src="media/category.jpg" />
									<div class="text-holder">
										<p class="uber-text">Dresses</p>
										<p>
											From mini dresses, to carefree maxi dresses and flowing midi lengths to cute flippy skirts, bodycon 	numbers and pieces made for your holidays - we've got a dress to suit every occasion!
										</p>
									</div>
									<div class="diagonal-holder out-of-bound">
										<div class="slider-diagonal-overflow">
											<div class="slider-diagonal rotate45"></div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="span9 filter-controls phone-span-diff">
							<div class="control-dropdown">
								<a href="#" class="filter">Sort by<span>name<span></span></span></a>
							</div>
							<div class="control-dropdown">
								<a href="#" class="filter">Show<span>9<span></span></span></a>
							</div>
							<a href="product_comparison.html" class="filter">Product compare (0)</a>
							<div class="control-dropdown">
								<a href="#" class="filter">View<span>grid<span></span></span></a>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="span3 product">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-image-1.png" />
								<div class="product-info">
									<span class="product-price"><img src="img/Indian_Rupee_symbol.png" height="5" width="20"> 125.50</span>
									<a href="product.html" class="product-name">Featured Item Title on two rows</a>
								</div>
								<div class="product-hover">
									<a href="product_comparison.html">+ compare</a>
									<a href="cart.html">+ wishlist</a>
									<a href="cart.html" class="add-shortcut">+</a>
								</div>
							</div>
						</div>
						<div class="span3 product">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-image-2.png" />
								<div class="product-info">
									<span class="product-price"><img src="img/Indian_Rupee_symbol.png" height="5" width="20"> 125.50</span>
									<a href="product.html" class="product-name">Featured Item Title on two rows</a>
								</div>
								<div class="product-hover">
									<a href="product_comparison.html">+ compare</a>
									<a href="cart.html">+ wishlist</a>
									<a href="cart.html" class="add-shortcut">+</a>
								</div>
							</div>
						</div>
						<div class="span3 product new-item">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-image-3.png" />
								<div class="product-info">
									<span class="product-price"><img src="img/Indian_Rupee_symbol.png" height="5" width="20"> 125.50</span>
									<a href="product.html" class="product-name">Featured Item Title on two rows</a>
								</div>
								<div class="product-hover">
									<a href="product_comparison.html">+ compare</a>
									<a href="cart.html">+ wishlist</a>
									<a href="cart.html" class="add-shortcut">+</a>
								</div>
							</div>
							<div class="product-badge rotate290">
								<span>new arrival</span>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="span3 product">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-image-1.png" />
								<div class="product-info">
									<span class="product-price"><img src="img/Indian_Rupee_symbol.png" height="5" width="20"> 125.50</span>
									<a href="product.html" class="product-name">Featured Item Title on two rows</a>
								</div>
								<div class="product-hover">
									<a href="product_comparison.html">+ compare</a>
									<a href="cart.html">+ wishlist</a>
									<a href="cart.html" class="add-shortcut">+</a>
								</div>
							</div>
						</div>
						<div class="span3 product">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-image-2.png" />
								<div class="product-info">
									<span class="product-price"><img src="img/Indian_Rupee_symbol.png" height="5" width="20"> 125.50</span>
									<a href="product.html" class="product-name">Featured Item Title on two rows</a>
								</div>
								<div class="product-hover">
									<a href="product_comparison.html">+ compare</a>
									<a href="cart.html">+ wishlist</a>
									<a href="cart.html" class="add-shortcut">+</a>
								</div>
							</div>
						</div>
						<div class="span3 product new-item">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-image-3.png" />
								<div class="product-info">
									<span class="product-price"><img src="img/Indian_Rupee_symbol.png" height="5" width="20"> 125.50</span>
									<a href="product.html" class="product-name">Featured Item Title on two rows</a>
								</div>
								<div class="product-hover">
									<a href="product_comparison.html">+ compare</a>
									<a href="cart.html">+ wishlist</a>
									<a href="cart.html" class="add-shortcut">+</a>
								</div>
							</div>
							<div class="product-badge rotate290">
								<span>new arrival</span>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="span3 product">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-image-1.png" />
								<div class="product-info">
									<span class="product-price"><img src="img/Indian_Rupee_symbol.png" height="5" width="20"> 125.50</span>
									<a href="product.html" class="product-name">Featured Item Title on two rows</a>
								</div>
								<div class="product-hover">
									<a href="product_comparison.html">+ compare</a>
									<a href="cart.html">+ wishlist</a>
									<a href="cart.html" class="add-shortcut">+</a>
								</div>
							</div>
						</div>
						<div class="span3 product">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-image-2.png" />
								<div class="product-info">
									<span class="product-price"><img src="img/Indian_Rupee_symbol.png" height="5" width="20"> 125.50</span>
									<a href="product.html" class="product-name">Featured Item Title on two rows</a>
								</div>
								<div class="product-hover">
									<a href="product_comparison.html">+ compare</a>
									<a href="cart.html">+ wishlist</a>
									<a href="cart.html" class="add-shortcut">+</a>
								</div>
							</div>
						</div>
						<div class="span3 product new-item">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-image-3.png" />
								<div class="product-info">
									<span class="product-price"><img src="img/Indian_Rupee_symbol.png" height="5" width="20"> 125.50</span>
									<a href="product.html" class="product-name">Featured Item Title on two rows</a>
								</div>
								<div class="product-hover">
									<a href="product_comparison.html">+ compare</a>
									<a href="cart.html">+ wishlist</a>
									<a href="cart.html" class="add-shortcut">+</a>
								</div>
							</div>
							<div class="product-badge rotate290">
								<span>new arrival</span>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="span2 offset7 pagination phone-center">
							<a href="#">1 /</a>
							<a href="#">2 /</a>
							<a href="#">3 /</a>
							<a href="#">... /</a>
							<a href="#">next /</a>
							<a href="#">last</a>
						</div>
					</div>
				</div>
			</div>
		</div><!-- end container -->

		<div class="footer-container inset-shadow">
			<div class="container footer">
				<div class="row">
					<div class="span3">
						<h2 class="footer-heading">Post Your Add Here</h2>
					</div>
					<div class="span2 offset1">
						<h2 class="footer-heading">Information</h2>
					</div>
					<div class="span2">
						<h2 class="footer-heading">Cust. Service</h2>
					</div>
					<div class="span3 offset1">
						<h2 class="footer-heading">Contact Us</h2>
					</div>
				</div>

				<div class="row">
					<div class="span3">
						<div class="footer-bag">
							<p>Post Your Add</p>
						</div>
						<a href="main_category.html" class="footer-promo">Post Adds</a>
					</div>
					<div class="span4 offset1">
						<div class="row">
							<div class="span2">
								<ul class="footer-nav-group">
									<li><a href="about.html">About us</a></li>
									<li><a href="account.html">Delivery</a></li>
									<li><a href="account.html">Privacy Policy</a></li>
									<li><a href="account.html">Terms and Conditions</a></li>
								</ul>
							</div>
							<div class="span2">
								<ul class="footer-nav-group">
									<li><a href="contact.html">Contact us</a></li>
									<li><a href="account.html">Returns</a></li>
									<li><a href="cart.html">Rates</a></li>
									<li><a href="#">Site Map</a></li>
								</ul>
							</div>
						</div>
						<div class="row">
							<div class="span2">
								<h2 class="footer-heading">Extras</h2>
							</div>
							<div class="span2">
								<h2 class="footer-heading">My Account</h2>
							</div>
						</div>
						<div class="row">
							<div class="span2">
								<ul class="footer-nav-group">
									<li><a href="category.html">Brands</a></li>
									<li><a href="account.html">Gift Vouchers</a></li>
									<li><a href="about.html">Affiliates</a></li>
									<li><a href="main_category.html">Specials</a></li>
								</ul>
							</div>
							<div class="span2">
								<ul class="footer-nav-group">
									<li><a href="account.html">Settings</a></li>
									<li><a href="account.html">Order History</a></li>
									<li><a href="cart.html">Wishlist</a></li>
									<li><a href="account.html">Newsletter</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="span3 offset1">
						<div class="google-map"><iframe width="640" height="480" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=77+charterhouse+street+london&amp;aq=&amp;sll=37.0625,-95.677068&amp;sspn=39.371738,86.572266&amp;t=h&amp;ie=UTF8&amp;hq=&amp;hnear=77+Charterhouse+St,+London+Borough+of+Islington,+London+EC1M,+United+Kingdom&amp;ll=51.52012,-0.100422&amp;spn=0.025635,0.054932&amp;z=14&amp;iwloc=A&amp;output=embed"></iframe><br /></div>
						<a href="#" class="mailto"><i class="icon-envelope"></i> jordan.grozdanov@gmail.com</a>
					</div>
				</div>

				<div class="row">
					<div class="span9">
						<ul class="social-links">
							<li><a href="#" id="facebook">Facebook</a></li>
							<li><a href="http://twitter.com/jgrozdanov" id="twitter">Twitter</a></li>
							<li><a href="#" id="google">Google+</a></li>
							<li><a href="#" id="tumblr">Tumblr</a></li>
							<li><a href="#" id="vimeo">Vimeo</a></li>
							<li><a href="#" id="youtube">YouTube</a></li>
						</ul>
					</div>
					<div class="span3">
						<p class="phones"><i class="icon-info-sign"></i> 0207 887 2614 0207 887 2615 0207 887 2613</p>
					</div>
				</div>

				<div class="row">
					<div class="span7 copyrights">
						<a href="index.html">Copyright @ Ananya Cosmetics 2013.</a>
						<p>
							Powered By <a href="http://www.wavetechline.com" target="_tab">Wavetechline India P.V.T.</a> All rights reserved.
						</p>
					</div>
					<div class="span5">
						&nbsp;
					</div>
				</div>
			</div><!-- end container /footer/ -->
		</div><!-- end footer-container -->

		<script src="js/hover.intent.js"></script>
		<script src="js/respond.min.js"></script>
		<script src="js/header.js"></script>
		<script src="js/products.js"></script>
		<script src="js/jquery.nouislider.min.js"></script>
		<script src="js/range-slider.js"></script>
	</body>

</html>
