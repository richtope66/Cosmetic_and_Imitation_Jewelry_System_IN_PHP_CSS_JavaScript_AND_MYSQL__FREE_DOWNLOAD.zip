
<!DOCTYPE html>

<html>

	<head>
		<meta charset="UTF-8" />
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />
		<title>Ananya Cosmetics</title>
		<link href="css/bootstrap.min.css" rel="stylesheet" />
		<link href="css/style.css" rel="stylesheet" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />

<!-- js files -->
<!-- color picker -->
<!-- jQuery framework -->
<script type="text/javascript" src="jscolor/jscolor.js"></script>
<!-- jQuery framework -->
<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<!-- jQueriy easing plugin-->
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<!-- lhpTwoColorButton plugin -->
<script type="text/javascript" src="js/jquery.lhpTwoColorButton.min.js"></script>
<!-- lhpTwoColorButton plugin -->
<script type="text/javascript" src="js/jquery.lhpMenuTwoColorButton.min.js"></script>
<!-- preview main js code -->
<script type="text/javascript" src="js/main.js"></script>

<script type="text/javascript" src="js/jquery-1.7.2.min.js"></script>
<!-- jQueriy easing plugin-->
<script type="text/javascript" src="js/jquery.easing.1.3.js"></script>
<!-- lhpTwoColorButton plugin -->
<script type="text/javascript" src="js/jquery.lhpTwoColorButton.min.js"></script>
<!-- lhpTwoColorButton plugin -->
<!-- preview main js code -->
<script type="text/javascript" src="js/main.js"></script>

<script type="text/javascript" src="jscolor/jscolor.js"></script>
        
		<!--[if lt IE 9]><link rel="stylesheet" type="text/css" href="css/ie8.css" /><![endif]-->
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<style type="text/css">
/* make keyframes that tell the start state and the end state of our object */
@-webkit-keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
@-moz-keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
@keyframes fadeIn { from { opacity:0; } to { opacity:1; } }
 
.fade-in {
    opacity:0;  /* make things invisible upon start */
    -webkit-animation:fadeIn ease-in 1;  /* call our keyframe named fadeIn, use animattion ease-in and repeat it only 1 time */
    -moz-animation:fadeIn ease-in 1;
    animation:fadeIn ease-in 1;
 
    -webkit-animation-fill-mode:forwards;  /* this makes sure that after animation is done we remain at the last keyframe value (opacity: 1)*/
    -moz-animation-fill-mode:forwards;
    animation-fill-mode:forwards;
 
    -webkit-animation-duration:1s;
    -moz-animation-duration:1s;
    animation-duration:1s;
}
 
.fade-in.one {
-webkit-animation-delay: 2.9s;
-moz-animation-delay: 2.9s;
animation-delay: 2.9s;
}
</style>
</head>

	<body>
		<div class="hidden" id="login-container">
			<div class="container">
				<div class="row" id="close-login">
					<div class="span8 offset2">
						<div class="login">
							<div class="row">
								<div class="span3 offset1 phone-block">
									<p class="primary white">Login</p>
									<p class="push30">E-mail:</p>
									<input type="text" />
									<p>Password:</p>
									<input type="text" />
									<a href="#" class="adtext forgotten">forgot your password?</a>
									<input type="submit" class="simple-submit secondary push30" value="login" />
								</div>
								<div class="span3 margin-left30 phone-block">
									<p class="primary white">New Customer</p>
									<p class="push30">New to Diagonal? Register here, we won’t disappoint you.</p>
									<input type="submit" class="simple-submit secondary push30" value="register" />
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="slider-container"> 
			<div class="top-slider">
				<div class="s1 focus first" id="1"></div>
				<div class="s2 hidden" id="2"></div>
				<div class="s3 hidden" id="3"></div>
                <div class="s4 hidden" id="4"></div>
                <div class="s5 hidden last" id="5"></div>
			</div>
			<div class="diagonal-holder">
				<div class="slider-diagonal-overflow">
					<div class="slider-diagonal rotate45"></div>
				</div>
			</div>
            
			 <div class="container"> 
				<div class="row"> 
					<div class="span12"> 
						<div class="header">
							<div class="row1">
								<div class="span3">
                                
									<a href="#" id="logo">	<img class="logo_c" src="media/LOGO/logo.png"><img class="d  fade-in one" src="media/LOGO/d.png"></a>
								</div>
                                
								<div class="span8 offset1">
									<ul id="menu">
                                    <li><a href="index.php">Home</a> 
										<li><a href="products.php">Products</a> 
											<div class="child-nav" style="display: none;">
												<div class="child-menu">
													<ul class="child-menu-main">
														<li><a href="http://www.olay.in/Pages/DefaultFlash.aspx" target="_tab">OLAY</a></li>
														<li><a href="http://www.lakmesalon.com" target="_tab">LAKME</a></li>
														<li><a href="http://www.dove.us" target="_tab">DOVE</a></li>
														<li><a href="http://www.garnier.in/_en/_in/home.aspx" target="_tab">GARNIER</a></li>
														<li><a href="http://ponds.in" target="_tab">PONDS</a></li>
														<li><a href="http://www.loreal.co.in/_hi/_in/index.aspx" target="_tab">L'OREAL</a></li>
												</div>
												
											</div>
										</li>
										<li><a href="imitation.php">Imitation Jwellery</a></li>
									<li><a href="tips.php">Beauty Tips</a> </li>
                                      	<!--  <div class="child-nav" style="display: none;">
												<div class="child-menu"> 
													<ul class="child-menu-main">
														<li><a href="hairs.php">HAIR</a></li>
														<li><a href="eyes.php">EYES</a></li>
														<li><a href="nose.php">NOSE</a></li>
														<li><a href="lips.php">LIPS</a></li>
														<li><a href="face.php">FACE</a></li>
														<li><a href="neck.php">NECK</a></li>
                                                        <li><a href="breast.php">BREAST</a></li>
                                                        <li><a href="nails.php">NAILS</a></li>
                                                        <li><a href="skin.php">SKIN</a></li>
                                                        <li><a href="foot.php">FOOT</a></li>
                                                    </ul>
												</div>
												
											</div>-->
                                        
                                        </li>
										<li><a href="contact.php">Contact</a></li>
										
										
									</ul>
								</div>
							</div>
						</div><!-- end header -->
					</div>
				</div>

				<div class="row">
					<div class="span5 offset6 slider-elements-holder">
						<div class="slider-elements cfocus cfirst" id="c1">
							<p class="uber-text">&nbsp;
							
							</p>
							<a href="#" class="uber-more"><img class="b" src="media/LOGO/b.png">All to make u look "Gorgeous..." </a>
						</div>
						<div class="slider-elements hidden" id="c2">
							<p class="uber-text">&nbsp;
								
							</p>
							<a href="#" class="uber-more"><img class="b" src="media/LOGO/b.png">All to make u look "Gorgeous..." </a>
						</div>
						<div class="slider-elements hidden clast" id="c3">
							<p class="uber-text">&nbsp;
								
							</p>
							<a href="#" class="uber-more"><img class="b" src="media/LOGO/b.png">All to make u look "Gorgeous..." </a> </a>
						</div>
					</div>
				</div>
                

				<div class="row">
					
                    <div class="span2 offset10">
                    <!--<div class="ana">
                    <img src="media/LOGO/Logo_c.png"></div>
                    -->
						<!--<ul id="slider-nav">
							<li><a href="#" class="t1 focused">1</a> /</li>
							<li><a href="#" class="t2">2</a> /</li>
							<li><a href="#" class="t3">3</a> / </li>
                            <li><a href="#" class="t4">4</a> / </li>
                            <li><a href="#" class="t5">5</a> </li>
						</ul>-->
					</div>
				</div>

				<div class="row">
					<div class="span3 slider-tile">
						<a href="#" class="slider-tile-thumb" id="slider-tile-thumb-1">thumb</a>
						<a href="#" class="slider-tile-heading">Summer 2012</a>
						<p>Check out our new collection and be prepared for the summer!</p>
					</div>
					<div class="span3 slider-tile">
						<a href="#" class="slider-tile-thumb" id="slider-tile-thumb-2">thumb</a>
						<a href="#" class="slider-tile-heading">Men Jackets</a>
						<p>Check out our new collection and be prepared for the summer!</p>
					</div>
					<div class="span3 slider-tile">
						<a href="#" class="slider-tile-thumb" id="slider-tile-thumb-3">thumb</a>
						<a href="#" class="slider-tile-heading">Vintage</a>
						<p>Check out our new collection and be prepared for the summer!</p>
					</div>
					<div class="span3 slider-tile">
						<a href="#" class="slider-tile-heading margin-left20">WE ARE LAUNCHING WORLDWIDE OUR SITES.</a>
					</div>
				</div>
			</div><!-- end container -->
		</div><!-- end slider container -->


		<div class="container">
			<div class="row">
				<div class="span12">
					<h2 class="section-heading">Featured Products</h2>
				</div>
			</div>
			<div class="row">
				<div class="span3 product">
					<div class="product-overflow-keeper">
						<img class="product-image" src="media/product-image-1.png" alt="product" />
						<div class="product-info">
							<span class="product-price"></span>
							<a href="#" class="product-name">&nbsp;</a>
						</div>
						<div class="product-hover">
							<a href="product_comparison.php">&nbsp;</a>
							<a href="#">&nbsp;</a>
							<a href="#">&nbsp;</a>
						</div>
					</div>
				</div>
				<div class="span3 product">
					<div class="product-overflow-keeper">
						<img class="product-image" src="media/product-image-2.png" alt="product" />
						<div class="product-info">
							<span class="product-price"></span>
							<a href="#" class="product-name">&nbsp;</a>
						</div>
						<div class="product-hover">
							<a href="product_comparison.php">&nbsp;</a>
							<a href="#">&nbsp;</a>
							<a href="#">&nbsp;</a>
						</div>

					</div>
				</div>
				<div class="span3 product new-item">
					<div class="product-overflow-keeper">
						<img class="product-image" src="media/product-image-3.png" alt="product" />
						<div class="product-info">
							<span class="product-price"></span>
							<a href="#" class="product-name">&nbsp;</a>
						</div>
						<div class="product-hover">
							<a href="product_comparison.php">&nbsp;</a>
							<a href="#">&nbsp;</a>
							<a href="#">&nbsp;</a>
						</div>
					</div>
					<div class="product-badge rotate290">
						<span>new arrival</span>
					</div>
				</div>
				<div class="span3 product">
					<div class="product-overflow-keeper">
						<img class="product-image" src="media/product-image-4.png" alt="product" />
						<div class="product-info">
							<span class="product-price"></span>
						<a href="#" class="product-name">&nbsp;</a>
						</div>
						<div class="product-hover">
							<a href="product_comparison.html">&nbsp;</a>
							<a href="#">&nbsp;</a>
							<a href="#">&nbsp;</a>
						</div>

					</div>
				</div>
			</div>


			<div class="row">
				<div class="span8">
					<div class="row">
						<div class="span8">
							<h2 class="section-heading hidden-phone">Latest Products</h2>
						</div>
					</div>

					<div class="row">
						<div class="span2 product-small">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-small-1.png" alt="product" />
								<div class="product-info">
									<span class="product-price"></span>
									<a href="#" class="product-name">&nbsp;</a>
						</div>
						<div class="product-hover">
							<a href="#.html">&nbsp;</a>
							<a href="#.html">&nbsp;</a>
							<a href="#.html">&nbsp;</a>
						</div>

							</div>
							<div class="product-badge rotate290">
								<span>bestseller</span>
							</div>
						</div>
						<div class="span2 product-small">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-small-2.png" alt="product" />
								<div class="product-info">
									<span class="product-price"></span>
									<a href="#" class="product-name">&nbsp;</a>
						</div>
						<div class="product-hover">
							<a href="product_comparison.php">&nbsp;</a>
							<a href="#">&nbsp;</a>
							<a href="#">&nbsp;</a>
						</div>

							</div>
						</div>
						<div class="span2 product-small">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-small-3.png" alt="product" />
								<div class="product-info">
									<span class="product-price"></span>
									<a href="#" class="product-name">&nbsp;</a>
						</div>
						<div class="product-hover">
							<a href="product_comparison.html">&nbsp;</a>
							<a href="#">&nbsp;</a>
							<a href="#">&nbsp;</a>
						</div>

							</div>
						</div>
						<div class="span2 product-small">
							<div class="product-overflow-keeper">
								<img class="product-image" src="media/product-small-4.png" alt="product" />
								<div class="product-info">
									<span class="product-price"></span>
									<a href="#" class="product-name">&nbsp;</a>
						</div>
						<div class="product-hover">
							<a href="product_comparison.html">&nbsp;</a>
							<a href="#">&nbsp;</a>
							<a href="#">&nbsp;</a>
						</div>

							</div>
							<div class="product-badge rotate290">
								<span>bestseller</span>
							</div>
						</div>
					</div>

					<div class="row">
						<div class="span8">
							<h2 class="section-heading">Featured Brands</h2>
						</div>
					</div>

					<div class="row">
						<div class="span8 featured-brands">
							<a href="#" class="featured-brands-prev">&lt;</a>
							<div>
								<div>
									<a href="#" class="featured-brand"><img src="media/brand1.png" alt="brand" /></a>
									<a href="#" class="featured-brand"><img src="media/brand1.png" alt="brand" /></a>
									<a href="#" class="featured-brand"><img src="media/brand1.png" alt="brand" /></a>
									<a href="#" class="featured-brand"><img src="media/brand1.png" alt="brand" /></a>
									<a href="#" class="featured-brand"><img src="media/brand1.png" alt="brand" /></a>
									<a href="#" class="featured-brand"><img src="media/brand1.png" alt="brand" /></a>
									<a href="#" class="featured-brand"><img src="media/brand1.png" alt="brand" /></a>
								</div>
							</div>
							<a href="#" class="featured-brands-next">&gt;</a>
						</div>
					</div>

					<div class="row">
						<div class="span8 banner">
							<a href="#" class="banner-link">Buy Now!</a>
						</div>
					</div>
				</div>


				<div class="span4">
					<div class="row">
						<div class="span4">
							<h2 class="section-heading">Newsletter</h2>
						</div>
					</div>

					<div class="row">
						<div class="span4 newsletter">
							<p class="newsletter-info">
								Welcome to Diagonal Shop PSD Template! Stay tuned for HTML/CSS version and make sure to leave a 
								comment which CMS platform you prefer for the working version! 
							</p>
							<div class="newsletter-inputs">
								<input type="text" class="newsletter-subscribe" placeholder="Your email..." />
								<input type="submit" value="Submit e-mail" />
							</div>
							<p>We won't spam you!</p>
						</div>
					</div>

<div class="row">
						<div class="span4">
							<h2 class="section-heading" >Post Your Adds Here</h2>
						</div>
					</div>

					<div class="row">
						<div class="span4">
							<div class="tweet hidden-tablet">
								<a href="http://twitter.com/jgrozdanov" target="_blank" class="twitter-avatar"><img src="media/tw-avatar.png" alt="twitter avatar" /></a>
								<div class="tweet-meta">
									<a href="http://twitter.com/jgrozdanov" target="_blank" class="twitter-name">JGrozdanov</a>
									<p class="tweet-body">Diagonal HTML Template - Wordpress or Shopify? Leave a comment.</p>
									<p class="tweet-timestamp"><i class="icon-time"></i> 30 Sep 2012 18:00</p>
								</div>
							</div>
							<div class="tweet hidden-tablet">
								<a href="http://twitter.com/jgrozdanov" target="_blank" class="twitter-avatar"><img src="media/tw-avatar.png" alt="twitter avatar" /></a>
								<div class="tweet-meta">
									<a href="http://twitter.com/jgrozdanov" target="_blank" class="twitter-name">JGrozdanov</a>
									<p class="tweet-body">
										Diagonal HTML Template - Wordpress or Shopify? Which WP Plugin? 
										Leave a comment.
									</p>
									<p class="tweet-timestamp"><i class="icon-time"></i> 30 Sep 2012 17:23</p>
								</div>
							</div>
							<div class="tweet">
								<a href="http://twitter.com/jgrozdanov" target="_blank" class="twitter-avatar"><img src="media/tw-avatar.png" alt="twitter avatar" /></a>
								<div class="tweet-meta">
									<a href="http://twitter.com/jgrozdanov" target="_blank" class="twitter-name">JGrozdanov</a>
									<p class="tweet-body">
										Hey, check out my ThemeForest item, it has some cool CSS3 animations - 
										<a href="http://themeforest.net/item/monochrome-html5css3-countdown-template/2444734" target="_blank">Monochrome HTML5/CSS3 Countdown Template</a>
									</p>
									<p class="tweet-timestamp"><i class="icon-time"></i> 30 Sep 2012 15:04</p>
								</div>
							</div>
							<div class="tweet">
								<a href="http://twitter.com/jgrozdanov" target="_blank" class="twitter-avatar"><img src="media/tw-avatar.png" alt="twitter avatar" /></a>
								<div class="tweet-meta">
									<a href="http://twitter.com/jgrozdanov" target="_blank" class="twitter-name">JGrozdanov</a>
									<p class="tweet-body">
										Follow me on Twitter - 
										<a href="http://twitter.com/jgrozdanov" target="_blank">@Jgrozdanov</a>
									</p>
									<p class="tweet-timestamp"><i class="icon-time"></i> 30 Sep 2012 15:04</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div><!-- end container -->


		<div class="footer-container inset-shadow">
			<div class="container footer">
				<div class="row">
					<div class="span3">
						<h2 class="footer-heading">Post Your Add Here</h2>
					</div>
					<div class="span2 offset1">
						<h2 class="footer-heading">Information</h2>
					</div>
					<div class="span2">
						<h2 class="footer-heading">Cust. Service</h2>
					</div>
					<div class="span3 offset1">
						<h2 class="footer-heading">Contact Us</h2>
					</div>
				</div>

				<div class="row">
					<div class="span3">
						<div class="footer-bag">
							<p>Post Adds</p>
						</div>
						<a href="main_#" class="footer-promo">Post Add</a>
					</div>
					<div class="span4 offset1">
						<div class="row">
							<div class="span2">
								<ul class="footer-nav-group">
									<li><a href="#">About us</a></li>
									<li><a href="#">Delivery</a></li>
									<li><a href="#">Privacy Policy</a></li>
									<li><a href="#">Terms and Conditions</a></li>
								</ul>
							</div>
							<div class="span2">
								<ul class="footer-nav-group">
									<li><a href="contact.php">Contact us</a></li>
									<li><a href="#">Returns</a></li>
									<li><a href="#">Rates</a></li>
									<li><a href="#">Site Map</a></li>
								</ul>
							</div>
						</div>
						<div class="row">
							<div class="span2">
								<h2 class="footer-heading">Extras</h2>
							</div>
							<div class="span2">
								<h2 class="footer-heading">My Account</h2>
							</div>
						</div>
						<div class="row">
							<div class="span2">
								<ul class="footer-nav-group">
									<li><a href="#">Brands</a></li>
									<li><a href="#">Gift Vouchers</a></li>
									<li><a href="#">Affiliates</a></li>
									<li><a href="#">Specials</a></li>
								</ul>
							</div>
							<div class="span2">
								<ul class="footer-nav-group">
									<li><a href="#">Settings</a></li>
									<li><a href="#">Order History</a></li>
									<li><a href="#">Wishlist</a></li>
									<li><a href="#">Newsletter</a></li>
								</ul>
							</div>
						</div>
					</div>
					<div class="span3 offset1">
						<div class="google-map"><iframe width="640" height="480" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.co.in/maps?hl=en&amp;ie=UTF8&amp;t=h&amp;ll=19.960381,73.827535&amp;spn=0.00353,0.00456&amp;z=17&amp;output=embed"></iframe><br /><small><a href="https://maps.google.co.in/maps?hl=en&amp;ie=UTF8&amp;t=h&amp;ll=19.960381,73.827535&amp;spn=0.00353,0.00456&amp;z=17&amp;source=embed" style="color:#0000FF;text-align:left">View Larger Map</a></small><br /></div>
						<a href="#" class="mailto"><i class="icon-envelope"></i> Email.@gmail.com</a>
					</div>
				</div>

				<div class="row">
					<div class="span9">
						<ul class="social-links">
							<li><a href="#" id="facebook">Facebook</a></li>
							<li><a href="http://twitter.com/jgrozdanov" id="twitter">Twitter</a></li>
							<li><a href="#" id="google">Google+</a></li>
							<li><a href="#" id="tumblr">Tumblr</a></li>
							<li><a href="#" id="vimeo">Vimeo</a></li>
							<li><a href="#" id="youtube">YouTube</a></li>
						</ul>
					</div>
					<div class="span3">
						<p class="phones"><i class="icon-info-sign"></i> 0207 887 2614 0207 887 2615 0207 887 2613</p>
					</div>
				</div>

				<div class="row">
					<div class="span7 copyrights">
						<a href="index.php">Copyright @ Ananya Cosmetics 2013.</a>
						<p>
							Powered By <a href="http://www.wavetechline.com" target="_tab">Wavetechline India P.V.T.</a> All rights reserved.
						</p>
					</div>
					<div class="span5">
					</div>
				</div>
			</div><!-- end container /footer/ -->
		</div><!-- end footer-container -->

		
		<script src="js/respond.min.js"></script>
		<script src="js/hover.intent.js"></script>
		<script src="js/header.js"></script>
		<script src="js/products.js"></script>
		<script src="js/slider.js"></script>
		<script src="js/utils.js"></script>
	</body>

</html>
